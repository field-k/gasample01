# gasample01
GA操作用のサンプルドメイン
